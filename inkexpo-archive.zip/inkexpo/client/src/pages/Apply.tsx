import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { Flame, Upload } from "lucide-react";
import { getLoginUrl } from "@/const";

export default function Apply() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // 表單狀態
  const [formData, setFormData] = useState({
    shopName: "",
    address: "",
    phone: "",
    email: "",
    yearsOfExperience: 1,
    bio: "",
    region: "",
    website: "",
    selectedStyles: [] as number[],
  });

  // 獲取紋身風格
  const { data: styles = [] } = trpc.tattooStyle.getAll.useQuery();

  // 提交申請
  const submitMutation = trpc.application.submit.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.shopName || !formData.address || !formData.phone || !formData.email) {
      toast.error("請填寫所有必填欄位");
      return;
    }

    if (formData.selectedStyles.length === 0) {
      toast.error("請至少選擇一種紋身風格");
      return;
    }

    setIsSubmitting(true);

    try {
      await submitMutation.mutateAsync({
        shopName: formData.shopName,
        address: formData.address,
        phone: formData.phone,
        email: formData.email,
        yearsOfExperience: formData.yearsOfExperience,
        bio: formData.bio,
        region: formData.region,
        website: formData.website,
        styleIds: formData.selectedStyles,
      });

      toast.success("申請已提交，等待管理員審核");
      setLocation("/dashboard");
    } catch (error: any) {
      toast.error(error.message || "申請提交失敗");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <nav className="border-b border-border bg-card/50 backdrop-blur">
          <div className="container flex justify-between items-center py-4">
            <button
              onClick={() => setLocation("/")}
              className="flex items-center gap-2 hover:text-accent transition"
            >
              <Flame className="w-6 h-6 text-accent" />
              <span className="ink-text">InkExpo</span>
            </button>
          </div>
        </nav>
        <div className="container py-12 text-center">
          <p className="text-muted-foreground mb-4">請先登入才能提交申請</p>
          <Button
            onClick={() => (window.location.href = getLoginUrl())}
            className="ink-button"
          >
            登入
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* 導航欄 */}
      <nav className="border-b border-border bg-card/50 backdrop-blur">
        <div className="container flex justify-between items-center py-4">
          <button
            onClick={() => setLocation("/")}
            className="flex items-center gap-2 hover:text-accent transition"
          >
            <Flame className="w-6 h-6 text-accent" />
            <span className="ink-text">InkExpo</span>
          </button>
          <button
            onClick={() => setLocation("/")}
            className="hover:text-accent transition"
          >
            返回首頁
          </button>
        </div>
      </nav>

      {/* 頁面標題 */}
      <section className="ink-gradient py-12">
        <div className="container">
          <h1 className="ink-heading mb-2">店家申請</h1>
          <p className="ink-subheading">
            填寫以下資訊提交您的紋身店家申請，等待管理員審核
          </p>
        </div>
      </section>

      {/* 申請表單 */}
      <section className="py-12">
        <div className="container max-w-2xl">
          <Card className="ink-card">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* 基本資訊 */}
              <div>
                <h3 className="text-lg font-bold text-accent mb-4">基本資訊</h3>

                <div className="space-y-4">
                  {/* 店名 */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">
                      店名 *
                    </label>
                    <Input
                      type="text"
                      placeholder="輸入您的紋身店名"
                      value={formData.shopName}
                      onChange={(e) =>
                        setFormData({ ...formData, shopName: e.target.value })
                      }
                      className="ink-input"
                      required
                    />
                  </div>

                  {/* 地址 */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">
                      地址 *
                    </label>
                    <Input
                      type="text"
                      placeholder="輸入完整地址"
                      value={formData.address}
                      onChange={(e) =>
                        setFormData({ ...formData, address: e.target.value })
                      }
                      className="ink-input"
                      required
                    />
                  </div>

                  {/* 地區 */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">
                      地區
                    </label>
                    <Input
                      type="text"
                      placeholder="例：台北市、東京都"
                      value={formData.region}
                      onChange={(e) =>
                        setFormData({ ...formData, region: e.target.value })
                      }
                      className="ink-input"
                    />
                  </div>

                  {/* 聯絡電話 */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">
                      聯絡電話 *
                    </label>
                    <Input
                      type="tel"
                      placeholder="輸入聯絡電話"
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData({ ...formData, phone: e.target.value })
                      }
                      className="ink-input"
                      required
                    />
                  </div>

                  {/* 電子郵件 */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">
                      電子郵件 *
                    </label>
                    <Input
                      type="email"
                      placeholder="輸入電子郵件"
                      value={formData.email}
                      onChange={(e) =>
                        setFormData({ ...formData, email: e.target.value })
                      }
                      className="ink-input"
                      required
                    />
                  </div>

                  {/* 資歷年份 */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">
                      資歷年份 *
                    </label>
                    <Input
                      type="number"
                      min="1"
                      value={formData.yearsOfExperience}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          yearsOfExperience: parseInt(e.target.value),
                        })
                      }
                      className="ink-input"
                      required
                    />
                  </div>

                  {/* 網站 */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">
                      官網連結（選填）
                    </label>
                    <Input
                      type="url"
                      placeholder="https://example.com"
                      value={formData.website}
                      onChange={(e) =>
                        setFormData({ ...formData, website: e.target.value })
                      }
                      className="ink-input"
                    />
                  </div>

                  {/* 簡介 */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">
                      店家簡介（選填）
                    </label>
                    <Textarea
                      placeholder="介紹您的店家和風格..."
                      value={formData.bio}
                      onChange={(e) =>
                        setFormData({ ...formData, bio: e.target.value })
                      }
                      className="ink-input"
                      rows={4}
                    />
                  </div>
                </div>
              </div>

              {/* 紋身風格 */}
              <div>
                <h3 className="text-lg font-bold text-accent mb-4">
                  紋身風格 *
                </h3>
                <p className="text-sm text-muted-foreground mb-4">
                  請選擇您擅長的紋身風格（至少選擇一個）
                </p>
                <div className="grid grid-cols-2 gap-4">
                  {styles.map((style: any) => (
                    <div key={style.id} className="flex items-center">
                      <Checkbox
                        id={`style-${style.id}`}
                        checked={formData.selectedStyles.includes(style.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setFormData({
                              ...formData,
                              selectedStyles: [
                                ...formData.selectedStyles,
                                style.id,
                              ],
                            });
                          } else {
                            setFormData({
                              ...formData,
                              selectedStyles: formData.selectedStyles.filter(
                                (id) => id !== style.id
                              ),
                            });
                          }
                        }}
                      />
                      <label
                        htmlFor={`style-${style.id}`}
                        className="ml-2 cursor-pointer"
                      >
                        {style.name}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              {/* 提交按鈕 */}
              <div className="flex gap-4">
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="ink-button flex-1"
                >
                  {isSubmitting ? "提交中..." : "提交申請"}
                </Button>
                <Button
                  type="button"
                  onClick={() => setLocation("/")}
                  variant="outline"
                  className="border-accent text-accent hover:bg-accent/10"
                >
                  取消
                </Button>
              </div>
            </form>
          </Card>

          {/* 提示 */}
          <Card className="ink-card mt-6 bg-accent/10 border border-accent">
            <p className="text-sm text-muted-foreground">
              💡 <strong>提示：</strong>
              申請提交後，管理員將審核您的資訊。審核通過後，您可以上傳作品照片並建立您的藝術家頁面。
            </p>
          </Card>
        </div>
      </section>

      {/* 頁腳 */}
      <footer className="border-t border-border bg-card/50 py-8 mt-12">
        <div className="container text-center text-muted-foreground">
          <p>&copy; 2026 InkExpo. 紋身藝術家推廣平台。</p>
        </div>
      </footer>
    </div>
  );
}
