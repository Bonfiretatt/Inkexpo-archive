import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Flame } from "lucide-react";
import { getLoginUrl } from "@/const";

export default function Dashboard() {
  const { user, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();

  // 獲取用戶的申請
  const { data: applications = [] } = trpc.application.getMyApplications.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  // 獲取用戶的藝術家資訊
  const { data: artist } = trpc.artist.getMe.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <nav className="border-b border-border bg-card/50 backdrop-blur">
          <div className="container flex justify-between items-center py-4">
            <button
              onClick={() => setLocation("/")}
              className="flex items-center gap-2 hover:text-accent transition"
            >
              <Flame className="w-6 h-6 text-accent" />
              <span className="ink-text">InkExpo</span>
            </button>
          </div>
        </nav>
        <div className="container py-12 text-center">
          <p className="text-muted-foreground mb-4">請先登入</p>
          <Button
            onClick={() => (window.location.href = getLoginUrl())}
            className="ink-button"
          >
            登入
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* 導航欄 */}
      <nav className="border-b border-border bg-card/50 backdrop-blur">
        <div className="container flex justify-between items-center py-4">
          <button
            onClick={() => setLocation("/")}
            className="flex items-center gap-2 hover:text-accent transition"
          >
            <Flame className="w-6 h-6 text-accent" />
            <span className="ink-text">InkExpo</span>
          </button>
          <div className="flex gap-4 items-center">
            <span className="text-muted-foreground">{user?.name}</span>
            <Button
              onClick={logout}
              variant="outline"
              className="border-accent text-accent hover:bg-accent/10"
            >
              登出
            </Button>
          </div>
        </div>
      </nav>

      {/* 頁面標題 */}
      <section className="ink-gradient py-12">
        <div className="container">
          <h1 className="ink-heading mb-2">我的儀表板</h1>
          <p className="ink-subheading">
            管理您的申請和藝術家資訊
          </p>
        </div>
      </section>

      {/* 儀表板內容 */}
      <section className="py-12">
        <div className="container">
          <Tabs defaultValue="applications">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="applications">我的申請</TabsTrigger>
              <TabsTrigger value="profile">我的資料</TabsTrigger>
            </TabsList>

            {/* 我的申請 */}
            <TabsContent value="applications" className="space-y-6 mt-6">
              {applications.length === 0 ? (
                <Card className="ink-card text-center py-12">
                  <p className="text-muted-foreground mb-4">
                    您還沒有提交任何申請
                  </p>
                  <Button
                    onClick={() => setLocation("/apply")}
                    className="ink-button"
                  >
                    提交申請
                  </Button>
                </Card>
              ) : (
                <div className="space-y-6">
                  {applications.map((app: any) => (
                    <Card key={app.id} className="ink-card">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-lg font-bold text-accent">
                            {app.shopName}
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            申請於 {new Date(app.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <span
                            className={`inline-block px-3 py-1 rounded-full text-sm font-semibold ${
                              app.status === "approved"
                                ? "bg-green-600/20 text-green-400"
                                : app.status === "rejected"
                                ? "bg-red-600/20 text-red-400"
                                : "bg-yellow-600/20 text-yellow-400"
                            }`}
                          >
                            {app.status === "approved"
                              ? "已批准"
                              : app.status === "rejected"
                              ? "已拒絕"
                              : "審核中"}
                          </span>
                        </div>
                      </div>

                      <div className="space-y-2 text-sm mb-4">
                        <p>
                          <strong>地址：</strong> {app.address}
                        </p>
                        <p>
                          <strong>電話：</strong> {app.phone}
                        </p>
                        <p>
                          <strong>郵件：</strong> {app.email}
                        </p>
                        <p>
                          <strong>資歷：</strong> {app.yearsOfExperience} 年
                        </p>
                      </div>

                      {app.status === "rejected" && app.rejectionReason && (
                        <div className="bg-red-600/10 border border-red-600/30 rounded p-3 mb-4">
                          <p className="text-sm">
                            <strong>拒絕原因：</strong> {app.rejectionReason}
                          </p>
                        </div>
                      )}

                      {app.status === "approved" && (
                        <Button
                          onClick={() => setLocation(`/artist/${app.id}`)}
                          className="ink-button w-full"
                        >
                          查看我的藝術家頁面
                        </Button>
                      )}
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            {/* 我的資料 */}
            <TabsContent value="profile" className="mt-6">
              {artist ? (
                <Card className="ink-card">
                  <h3 className="text-lg font-bold text-accent mb-4">
                    藝術家資訊
                  </h3>

                  <div className="space-y-3 text-sm mb-6">
                    <p>
                      <strong>店名：</strong> {artist.shopName}
                    </p>
                    <p>
                      <strong>地址：</strong> {artist.address}
                    </p>
                    <p>
                      <strong>電話：</strong> {artist.phone}
                    </p>
                    <p>
                      <strong>郵件：</strong> {artist.email}
                    </p>
                    <p>
                      <strong>資歷：</strong> {artist.yearsOfExperience} 年
                    </p>
                    {artist.region && (
                      <p>
                        <strong>地區：</strong> {artist.region}
                      </p>
                    )}
                    {artist.bio && (
                      <p>
                        <strong>簡介：</strong> {artist.bio}
                      </p>
                    )}
                  </div>

                  <Button
                    onClick={() => setLocation(`/artist/${artist.id}`)}
                    className="ink-button w-full"
                  >
                    查看我的頁面
                  </Button>
                </Card>
              ) : (
                <Card className="ink-card text-center py-12">
                  <p className="text-muted-foreground mb-4">
                    您的申請還未被批准
                  </p>
                  <Button
                    onClick={() => setLocation("/apply")}
                    className="ink-button"
                  >
                    提交申請
                  </Button>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* 頁腳 */}
      <footer className="border-t border-border bg-card/50 py-8 mt-12">
        <div className="container text-center text-muted-foreground">
          <p>&copy; 2026 InkExpo. 紋身藝術家推廣平台。</p>
        </div>
      </footer>
    </div>
  );
}
