import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { useLocation } from "wouter";
import { Search, MapPin, Flame } from "lucide-react";

export default function Directory() {
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedStyle, setSelectedStyle] = useState<string>("");
  const [selectedRegion, setSelectedRegion] = useState<string>("");
  const [selectedExperience, setSelectedExperience] = useState<string>("");

  // 獲取所有藝術家
  const { data: artists = [] } = trpc.artist.getApproved.useQuery({
    limit: 100,
  });

  // 獲取所有紋身風格
  const { data: styles = [] } = trpc.tattooStyle.getAll.useQuery();

  // 篩選逐輯
  const filteredArtists = useMemo(() => {
    return artists.filter((artist: any) => {
      // 搜尋條件
      if (
        searchTerm &&
        !artist.shopName.toLowerCase().includes(searchTerm.toLowerCase())
      ) {
        return false;
      }

      // 地區篩選
      if (selectedRegion && artist.region !== selectedRegion) {
        return false;
      }

      // 資歷篩選
      if (selectedExperience) {
        const exp = parseInt(selectedExperience);
        if (artist.yearsOfExperience < exp) {
          return false;
        }
      }

      return true;
    });
  }, [artists, searchTerm, selectedRegion, selectedExperience]);

  // 獲取所有地區
  const regions = useMemo(() => {
    const regionSet = new Set(artists.map((a: any) => a.region).filter(Boolean));
    return Array.from(regionSet).sort();
  }, [artists]);

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* 導航欄 */}
      <nav className="border-b border-border bg-card/50 backdrop-blur">
        <div className="container flex justify-between items-center py-4">
          <button
            onClick={() => setLocation("/")}
            className="flex items-center gap-2 hover:text-accent transition"
          >
            <Flame className="w-6 h-6 text-accent" />
            <span className="ink-text">InkExpo</span>
          </button>
          <button
            onClick={() => setLocation("/")}
            className="hover:text-accent transition"
          >
            返回首頁
          </button>
        </div>
      </nav>

      {/* 頁面標題 */}
      <section className="ink-gradient py-12">
        <div className="container">
          <h1 className="ink-heading mb-2">藝術家目錄</h1>
          <p className="ink-subheading">
            發現全球頂級紋身藝術家，瀏覽他們的作品和風格
          </p>
        </div>
      </section>

      {/* 篩選區 */}
      <section className="py-8 bg-card/20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* 搜尋框 */}
            <div className="relative">
              <Search className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="搜尋店名..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="ink-input pl-10"
              />
            </div>

            {/* 風格篩選 */}
            <Select value={selectedStyle} onValueChange={setSelectedStyle}>
              <option value="">所有風格</option>
              {styles.map((style: any) => (
                <option key={style.id} value={style.id.toString()}>
                  {style.name}
                </option>
              ))}
            </Select>

            {/* 地區篩選 */}
            <Select value={selectedRegion} onValueChange={setSelectedRegion}>
              <option value="">所有地區</option>
              {regions.map((region: any) => (
                <option key={region} value={region}>
                  {region}
                </option>
              ))}
            </Select>

            {/* 資歷篩選 */}
            <Select
              value={selectedExperience}
              onValueChange={setSelectedExperience}
            >
              <option value="">所有資歷</option>
              <option value="1">1年以上</option>
              <option value="3">3年以上</option>
              <option value="5">5年以上</option>
              <option value="10">10年以上</option>
            </Select>
          </div>
        </div>
      </section>

      {/* 藝術家列表 */}
      <section className="py-12">
        <div className="container">
          <p className="text-muted-foreground mb-6">
            找到 {filteredArtists.length} 位藝術家
          </p>

          {filteredArtists.length === 0 ? (
            <Card className="ink-card text-center py-12">
              <p className="text-muted-foreground">
                沒有找到符合條件的藝術家，請嘗試調整篩選條件。
              </p>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredArtists.map((artist: any) => (
                <Card
                  key={artist.id}
                  className="ink-card hover:shadow-lg transition cursor-pointer"
                  onClick={() => setLocation(`/artist/${artist.id}`)}
                >
                  {/* 店家頭像 */}
                  {artist.profileImageUrl && (
                    <div className="mb-4 h-40 bg-black rounded overflow-hidden">
                      <img
                        src={artist.profileImageUrl}
                        alt={artist.shopName}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}

                  {/* 店家資訊 */}
                  <h3 className="text-lg font-bold text-accent mb-2">
                    {artist.shopName}
                  </h3>

                  {/* 地區 */}
                  {artist.region && (
                    <div className="flex items-center gap-2 mb-2 text-sm text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      {artist.region}
                    </div>
                  )}

                  {/* 資歷 */}
                  <p className="text-sm text-muted-foreground mb-3">
                    資歷：{artist.yearsOfExperience} 年
                  </p>

                  {/* 簡介 */}
                  {artist.bio && (
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                      {artist.bio}
                    </p>
                  )}

                  {/* 查看詳情按鈕 */}
                  <Button
                    onClick={(e) => {
                      e.stopPropagation();
                      setLocation(`/artist/${artist.id}`);
                    }}
                    className="ink-button w-full"
                  >
                    查看詳情
                  </Button>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* 頁腳 */}
      <footer className="border-t border-border bg-card/50 py-8 mt-12">
        <div className="container text-center text-muted-foreground">
          <p>&copy; 2026 InkExpo. 紋身藝術家推廣平台。</p>
        </div>
      </footer>
    </div>
  );
}
