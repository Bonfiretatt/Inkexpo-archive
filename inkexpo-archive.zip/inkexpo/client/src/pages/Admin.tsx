import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Flame, CheckCircle, XCircle } from "lucide-react";
import { getLoginUrl } from "@/const";

export default function Admin() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("pending");
  const [rejectionReason, setRejectionReason] = useState<Record<number, string>>({});

  // 檢查是否為管理員
  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <nav className="border-b border-border bg-card/50 backdrop-blur">
          <div className="container flex justify-between items-center py-4">
            <button
              onClick={() => setLocation("/")}
              className="flex items-center gap-2 hover:text-accent transition"
            >
              <Flame className="w-6 h-6 text-accent" />
              <span className="ink-text">InkExpo</span>
            </button>
          </div>
        </nav>
        <div className="container py-12 text-center">
          <p className="text-muted-foreground mb-4">
            您沒有權限訪問此頁面
          </p>
          <Button
            onClick={() => {
              if (isAuthenticated) {
                setLocation("/");
              } else {
                window.location.href = getLoginUrl();
              }
            }}
            className="ink-button"
          >
            {isAuthenticated ? "返回首頁" : "登入"}
          </Button>
        </div>
      </div>
    );
  }

  // 獲取待審核申請
  const { data: pendingApplications = [], refetch: refetchPending } =
    trpc.application.getPending.useQuery({ limit: 50 });

  // 審核申請
  const reviewMutation = trpc.application.review.useMutation();

  const handleReview = async (
    applicationId: number,
    status: "approved" | "rejected"
  ) => {
    try {
      await reviewMutation.mutateAsync({
        applicationId,
        status,
        rejectionReason: rejectionReason[applicationId],
      });

      toast.success(
        status === "approved" ? "申請已批准" : "申請已拒絕"
      );
      refetchPending();
      setRejectionReason({
        ...rejectionReason,
        [applicationId]: "",
      });
    } catch (error: any) {
      toast.error(error.message || "操作失敗");
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* 導航欄 */}
      <nav className="border-b border-border bg-card/50 backdrop-blur">
        <div className="container flex justify-between items-center py-4">
          <button
            onClick={() => setLocation("/")}
            className="flex items-center gap-2 hover:text-accent transition"
          >
            <Flame className="w-6 h-6 text-accent" />
            <span className="ink-text">InkExpo</span>
          </button>
          <div className="flex gap-4">
            <button
              onClick={() => setLocation("/")}
              className="hover:text-accent transition"
            >
              返回首頁
            </button>
          </div>
        </div>
      </nav>

      {/* 頁面標題 */}
      <section className="ink-gradient py-12">
        <div className="container">
          <h1 className="ink-heading mb-2">管理員後台</h1>
          <p className="ink-subheading">
            審核店家申請，管理平台內容
          </p>
        </div>
      </section>

      {/* 管理內容 */}
      <section className="py-12">
        <div className="container">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="pending">待審核申請</TabsTrigger>
              <TabsTrigger value="settings">設定</TabsTrigger>
            </TabsList>

            {/* 待審核申請 */}
            <TabsContent value="pending" className="space-y-6 mt-6">
              <p className="text-muted-foreground">
                共有 {pendingApplications.length} 個待審核申請
              </p>

              {pendingApplications.length === 0 ? (
                <Card className="ink-card text-center py-12">
                  <p className="text-muted-foreground">暫無待審核申請</p>
                </Card>
              ) : (
                <div className="space-y-6">
                  {pendingApplications.map((app: any) => (
                    <Card key={app.id} className="ink-card">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* 申請資訊 */}
                        <div>
                          <h3 className="text-lg font-bold text-accent mb-4">
                            {app.shopName}
                          </h3>

                          <div className="space-y-2 text-sm">
                            <p>
                              <strong>地址：</strong> {app.address}
                            </p>
                            <p>
                              <strong>電話：</strong> {app.phone}
                            </p>
                            <p>
                              <strong>郵件：</strong> {app.email}
                            </p>
                            <p>
                              <strong>地區：</strong> {app.region || "未填"}
                            </p>
                            <p>
                              <strong>資歷：</strong> {app.yearsOfExperience} 年
                            </p>
                            {app.bio && (
                              <p>
                                <strong>簡介：</strong> {app.bio}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* 審核操作 */}
                        <div className="space-y-4">
                          <div>
                            <label className="block text-sm font-semibold mb-2">
                              拒絕原因（選填）
                            </label>
                            <Textarea
                              placeholder="如果拒絕此申請，請說明原因..."
                              value={rejectionReason[app.id] || ""}
                              onChange={(e) =>
                                setRejectionReason({
                                  ...rejectionReason,
                                  [app.id]: e.target.value,
                                })
                              }
                              className="ink-input"
                              rows={3}
                            />
                          </div>

                          <div className="flex gap-3">
                            <Button
                              onClick={() =>
                                handleReview(app.id, "approved")
                              }
                              className="flex-1 bg-green-600 hover:bg-green-700 text-white font-bold"
                            >
                              <CheckCircle className="w-4 h-4 mr-2" />
                              批准
                            </Button>
                            <Button
                              onClick={() =>
                                handleReview(app.id, "rejected")
                              }
                              className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold"
                            >
                              <XCircle className="w-4 h-4 mr-2" />
                              拒絕
                            </Button>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            {/* 設定 */}
            <TabsContent value="settings" className="mt-6">
              <Card className="ink-card">
                <h3 className="text-lg font-bold text-accent mb-4">系統設定</h3>
                <p className="text-muted-foreground">
                  更多管理功能即將推出...
                </p>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* 頁腳 */}
      <footer className="border-t border-border bg-card/50 py-8 mt-12">
        <div className="container text-center text-muted-foreground">
          <p>&copy; 2026 InkExpo. 紋身藝術家推廣平台。</p>
        </div>
      </footer>
    </div>
  );
}
