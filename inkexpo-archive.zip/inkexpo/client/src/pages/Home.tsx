import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";
import { Flame, Users, Palette, Award } from "lucide-react";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* 導航欄 */}
      <nav className="border-b border-border bg-card/50 backdrop-blur">
        <div className="container flex justify-between items-center py-4">
          <div className="flex items-center gap-2">
            <Flame className="w-8 h-8 text-accent" />
            <h1 className="ink-text text-2xl">InkExpo</h1>
          </div>
          <div className="flex gap-4 items-center">
            <button
              onClick={() => setLocation("/directory")}
              className="hover:text-accent transition"
            >
              藝術家目錄
            </button>
            {isAuthenticated ? (
              <>
                <button
                  onClick={() => setLocation("/dashboard")}
                  className="hover:text-accent transition"
                >
                  我的儀表板
                </button>
                {user?.role === "admin" && (
                  <button
                    onClick={() => setLocation("/admin")}
                    className="hover:text-accent transition"
                  >
                    管理後台
                  </button>
                )}
              </>
            ) : null}
          </div>
        </div>
      </nav>

      {/* 英雄區 */}
      <section className="ink-gradient py-20">
        <div className="container text-center">
          <h2 className="ink-heading mb-4">紋身藝術家的線上展示平台</h2>
          <p className="ink-subheading mb-8 max-w-2xl mx-auto">
            發現世界各地的頂級紋身藝術家，展示您的作品，與全球紋身愛好者連接。
          </p>
          <div className="flex gap-4 justify-center">
            {isAuthenticated ? (
              <>
                <Button
                  onClick={() => setLocation("/apply")}
                  className="ink-button"
                >
                  提交申請
                </Button>
                <Button
                  onClick={() => setLocation("/directory")}
                  variant="outline"
                  className="border-accent text-accent hover:bg-accent/10"
                >
                  瀏覽藝術家
                </Button>
              </>
            ) : (
              <>
                <Button
                  onClick={() => (window.location.href = getLoginUrl())}
                  className="ink-button"
                >
                  登入申請
                </Button>
                <Button
                  onClick={() => setLocation("/directory")}
                  variant="outline"
                  className="border-accent text-accent hover:bg-accent/10"
                >
                  瀏覽藝術家
                </Button>
              </>
            )}
          </div>
        </div>
      </section>

      {/* 功能介紹 */}
      <section className="py-16">
        <div className="container">
          <h3 className="ink-heading text-center mb-12">平台功能</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* 功能卡片 1 */}
            <Card className="ink-card">
              <div className="flex justify-center mb-4">
                <Users className="w-12 h-12 text-accent" />
              </div>
              <h4 className="text-lg font-bold text-center mb-2">藝術家目錄</h4>
              <p className="text-muted-foreground text-sm text-center">
                瀏覽全球頂級紋身藝術家，按風格、地區和資歷篩選
              </p>
            </Card>

            {/* 功能卡片 2 */}
            <Card className="ink-card">
              <div className="flex justify-center mb-4">
                <Palette className="w-12 h-12 text-accent" />
              </div>
              <h4 className="text-lg font-bold text-center mb-2">作品展示</h4>
              <p className="text-muted-foreground text-sm text-center">
                展示您的紋身作品集，上傳高質量的作品照片
              </p>
            </Card>

            {/* 功能卡片 3 */}
            <Card className="ink-card">
              <div className="flex justify-center mb-4">
                <Award className="w-12 h-12 text-accent" />
              </div>
              <h4 className="text-lg font-bold text-center mb-2">專業認證</h4>
              <p className="text-muted-foreground text-sm text-center">
                通過審核流程，獲得平台認證，建立信譽
              </p>
            </Card>

            {/* 功能卡片 4 */}
            <Card className="ink-card">
              <div className="flex justify-center mb-4">
                <Flame className="w-12 h-12 text-accent" />
              </div>
              <h4 className="text-lg font-bold text-center mb-2">社群連接</h4>
              <p className="text-muted-foreground text-sm text-center">
                與紋身愛好者和其他藝術家建立聯繫
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* 紋身風格介紹 */}
      <section className="py-16 bg-card/30">
        <div className="container">
          <h3 className="ink-heading text-center mb-12">紋身風格</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {[
              { name: "日式", desc: "色彩鮮豔、線條流暢" },
              { name: "美式傳統", desc: "粗黑線條、鮮豔色彩" },
              { name: "寫實", desc: "高度逼真、細節豐富" },
              { name: "幾何", desc: "對稱設計、現代風格" },
              { name: "水墨", desc: "意境深遠、筆觸自然" },
            ].map((style) => (
              <div key={style.name} className="ink-card text-center">
                <h4 className="text-accent font-bold mb-2">{style.name}</h4>
                <p className="text-sm text-muted-foreground">{style.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 頁腳 */}
      <footer className="border-t border-border bg-card/50 py-8">
        <div className="container text-center text-muted-foreground">
          <p>&copy; 2026 InkExpo. 紋身藝術家推廣平台。保留所有權利。</p>
          <p className="text-sm mt-2">
            未來功能：Web3D 線上展、NFT 門票、紋身比賽投票系統
          </p>
        </div>
      </footer>
    </div>
  );
}
