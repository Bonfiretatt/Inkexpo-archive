import { useParams, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Spinner } from "@/components/ui/spinner";
import { MapPin, Globe, Mail, Phone, Flame } from "lucide-react";

export default function ArtistDetail() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const artistId = id ? parseInt(id) : 0;

  // 獲取藝術家詳細資訊
  const { data: artist, isLoading: artistLoading } = trpc.artist.getById.useQuery({
    id: artistId,
  });

  // 獲取藝術家的作品集
  const { data: portfolios = [] } = trpc.portfolio.getByArtistId.useQuery({
    artistId: artistId,
  });

  if (artistLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Spinner />
      </div>
    );
  }

  if (!artist) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <nav className="border-b border-border bg-card/50 backdrop-blur">
          <div className="container flex justify-between items-center py-4">
            <button
              onClick={() => setLocation("/")}
              className="flex items-center gap-2 hover:text-accent transition"
            >
              <Flame className="w-6 h-6 text-accent" />
              <span className="ink-text">InkExpo</span>
            </button>
          </div>
        </nav>
        <div className="container py-12 text-center">
          <p className="text-muted-foreground">藝術家不存在</p>
          <Button
            onClick={() => setLocation("/directory")}
            className="ink-button mt-4"
          >
            返回目錄
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* 導航欄 */}
      <nav className="border-b border-border bg-card/50 backdrop-blur">
        <div className="container flex justify-between items-center py-4">
          <button
            onClick={() => setLocation("/")}
            className="flex items-center gap-2 hover:text-accent transition"
          >
            <Flame className="w-6 h-6 text-accent" />
            <span className="ink-text">InkExpo</span>
          </button>
          <div className="flex gap-4">
            <button
              onClick={() => setLocation("/directory")}
              className="hover:text-accent transition"
            >
              返回目錄
            </button>
          </div>
        </div>
      </nav>

      {/* 藝術家頭部 */}
      <section className="ink-gradient py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* 頭像 */}
            <div>
              {artist.profileImageUrl ? (
                <div className="ink-image-frame">
                  <img
                    src={artist.profileImageUrl}
                    alt={artist.shopName}
                    className="w-full h-80 object-cover"
                  />
                </div>
              ) : (
                <div className="ink-card h-80 flex items-center justify-center">
                  <span className="text-muted-foreground">無頭像</span>
                </div>
              )}
            </div>

            {/* 基本資訊 */}
            <div className="md:col-span-2">
              <h1 className="ink-heading mb-4">{artist.shopName}</h1>

              {/* 資歷 */}
              <div className="mb-6">
                <p className="text-muted-foreground mb-2">資歷</p>
                <p className="text-2xl font-bold text-accent">
                  {artist.yearsOfExperience} 年
                </p>
              </div>

              {/* 地區 */}
              {artist.region && (
                <div className="flex items-center gap-2 mb-4">
                  <MapPin className="w-5 h-5 text-accent" />
                  <span>{artist.region}</span>
                </div>
              )}

              {/* 聯絡方式 */}
              <div className="space-y-3 mb-6">
                {artist.email && (
                  <div className="flex items-center gap-2">
                    <Mail className="w-5 h-5 text-accent" />
                    <a
                      href={`mailto:${artist.email}`}
                      className="text-accent hover:underline"
                    >
                      {artist.email}
                    </a>
                  </div>
                )}
                {artist.phone && (
                  <div className="flex items-center gap-2">
                    <Phone className="w-5 h-5 text-accent" />
                    <a href={`tel:${artist.phone}`} className="hover:text-accent">
                      {artist.phone}
                    </a>
                  </div>
                )}
                {artist.website && (
                  <div className="flex items-center gap-2">
                    <Globe className="w-5 h-5 text-accent" />
                    <a
                      href={artist.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-accent hover:underline"
                    >
                      訪問網站
                    </a>
                  </div>
                )}
              </div>

              {/* 簡介 */}
              {artist.bio && (
                <div>
                  <p className="text-muted-foreground mb-2">簡介</p>
                  <p className="text-foreground">{artist.bio}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* 作品集 */}
      <section className="py-12">
        <div className="container">
          <h2 className="ink-heading mb-8">作品集</h2>

          {portfolios.length === 0 ? (
            <Card className="ink-card text-center py-12">
              <p className="text-muted-foreground">暫無作品展示</p>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {portfolios.map((portfolio: any) => (
                <div key={portfolio.id} className="ink-image-frame">
                  <img
                    src={portfolio.imageUrl}
                    alt={portfolio.title || "作品"}
                    className="w-full h-64 object-cover"
                  />
                  {portfolio.title && (
                    <div className="p-4 bg-card/50">
                      <h4 className="font-bold text-accent mb-2">
                        {portfolio.title}
                      </h4>
                      {portfolio.description && (
                        <p className="text-sm text-muted-foreground">
                          {portfolio.description}
                        </p>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* 頁腳 */}
      <footer className="border-t border-border bg-card/50 py-8 mt-12">
        <div className="container text-center text-muted-foreground">
          <p>&copy; 2026 InkExpo. 紋身藝術家推廣平台。</p>
        </div>
      </footer>
    </div>
  );
}
