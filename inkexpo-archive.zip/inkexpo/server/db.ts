import { eq, and, inArray, like, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, artists, portfolios, applications, tattooStyles, artistStyles, applicationStyles, applicationPortfolios } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * ============================================================
 * 藝術家相關查詢
 * ============================================================
 */

export async function getArtistById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(artists).where(eq(artists.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getArtistByUserId(userId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(artists).where(eq(artists.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getApprovedArtists(limit?: number, offset?: number) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(artists).where(eq(artists.status, 'approved')).orderBy(desc(artists.createdAt)) as any;
  
  if (limit) {
    query = query.limit(limit);
  }
  if (offset) {
    query = query.offset(offset);
  }

  return await query;
}

export async function searchArtists(searchTerm: string, limit?: number) {
  const db = await getDb();
  if (!db) return [];

  let query = db
    .select()
    .from(artists)
    .where(
      and(
        eq(artists.status, 'approved'),
        like(artists.shopName, `%${searchTerm}%`)
      )
    )
    .orderBy(desc(artists.createdAt)) as any;

  if (limit) {
    return await query.limit(limit);
  }

  return await query;
}

export async function filterArtists(filters: {
  styleIds?: number[];
  region?: string;
  yearsOfExperienceMin?: number;
  yearsOfExperienceMax?: number;
  limit?: number;
  offset?: number;
}) {
  const db = await getDb();
  if (!db) return [];

  let conditions = [eq(artists.status, 'approved')];

  if (filters.region) {
    conditions.push(eq(artists.region, filters.region));
  }

  if (filters.yearsOfExperienceMin !== undefined) {
    conditions.push(eq(artists.yearsOfExperience, filters.yearsOfExperienceMin));
  }

  let query = db.select().from(artists).where(and(...conditions)).orderBy(desc(artists.createdAt)) as any;

  if (filters.limit) {
    query = query.limit(filters.limit);
  }
  if (filters.offset) {
    query = query.offset(filters.offset);
  }

  return await query;
}

/**
 * ============================================================
 * 作品集相關查詢
 * ============================================================
 */

export async function getPortfoliosByArtistId(artistId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(portfolios)
    .where(eq(portfolios.artistId, artistId))
    .orderBy(portfolios.displayOrder);
}

export async function addPortfolio(data: typeof portfolios.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(portfolios).values(data);
  return result;
}

/**
 * ============================================================
 * 申請相關查詢
 * ============================================================
 */

export async function getPendingApplications(limit?: number, offset?: number) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(applications).where(eq(applications.status, 'pending')).orderBy(desc(applications.createdAt)) as any;

  if (limit) {
    query = query.limit(limit);
  }
  if (offset) {
    query = query.offset(offset);
  }

  return await query;
}

export async function getApplicationById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(applications).where(eq(applications.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getApplicationsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(applications).where(eq(applications.userId, userId)).orderBy(desc(applications.createdAt));
}

export async function createApplication(data: typeof applications.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(applications).values(data);
  return result;
}

export async function updateApplicationStatus(applicationId: number, status: 'approved' | 'rejected', rejectionReason?: string, reviewedBy?: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const updateData: Record<string, unknown> = {
    status,
    reviewedAt: new Date(),
  };

  if (reviewedBy) {
    updateData.reviewedBy = reviewedBy;
  }

  if (rejectionReason) {
    updateData.rejectionReason = rejectionReason;
  }

  return await db.update(applications).set(updateData).where(eq(applications.id, applicationId));
}

/**
 * ============================================================
 * 紋身風格相關查詢
 * ============================================================
 */

export async function getAllTattooStyles() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(tattooStyles);
}

export async function getTattooStyleById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(tattooStyles).where(eq(tattooStyles.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

/**
 * ============================================================
 * 藝術家風格關聯查詢
 * ============================================================
 */

export async function getArtistStyles(artistId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(artistStyles).where(eq(artistStyles.artistId, artistId));
}

export async function addArtistStyle(artistId: number, styleId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(artistStyles).values({ artistId, styleId });
}
