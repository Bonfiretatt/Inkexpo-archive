import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";

// 定義 admin 專用程序
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== 'admin') {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'Admin access required' });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  /**
   * ============================================================
   * 藝術家相關路由
   * ============================================================
   */
  artist: router({
    // 獲取所有已批准的藝術家
    getApproved: publicProcedure
      .input(z.object({
        limit: z.number().optional(),
        offset: z.number().optional(),
      }))
      .query(async ({ input }) => {
        const artists = await db.getApprovedArtists(input.limit, input.offset);
        return artists;
      }),

    // 搜尋藝術家
    search: publicProcedure
      .input(z.object({
        searchTerm: z.string(),
        limit: z.number().optional(),
      }))
      .query(async ({ input }) => {
        const artists = await db.searchArtists(input.searchTerm, input.limit);
        return artists;
      }),

    // 篩選藝術家
    filter: publicProcedure
      .input(z.object({
        styleIds: z.number().array().optional(),
        region: z.string().optional(),
        yearsOfExperienceMin: z.number().optional(),
        yearsOfExperienceMax: z.number().optional(),
        limit: z.number().optional(),
        offset: z.number().optional(),
      }))
      .query(async ({ input }) => {
        const artists = await db.filterArtists(input);
        return artists;
      }),

    // 獲取藝術家詳細資訊
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const artist = await db.getArtistById(input.id);
        if (!artist) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Artist not found' });
        }
        return artist;
      }),

    // 獲取當前用戶的藝術家資訊
    getMe: protectedProcedure
      .query(async ({ ctx }) => {
        const artist = await db.getArtistByUserId(ctx.user.id);
        return artist;
      }),
  }),

  /**
   * ============================================================
   * 作品集相關路由
   * ============================================================
   */
  portfolio: router({
    // 獲取藝術家的所有作品
    getByArtistId: publicProcedure
      .input(z.object({ artistId: z.number() }))
      .query(async ({ input }) => {
        const portfolios = await db.getPortfoliosByArtistId(input.artistId);
        return portfolios;
      }),

    // 上傳作品照片
    upload: protectedProcedure
      .input(z.object({
        artistId: z.number(),
        imageUrl: z.string(),
        imageKey: z.string(),
        title: z.string().optional(),
        description: z.string().optional(),
        styleId: z.number().optional(),
        displayOrder: z.number().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        // 驗證用戶是否為該藝術家
        const artist = await db.getArtistById(input.artistId);
        if (!artist || artist.userId !== ctx.user.id) {
          throw new TRPCError({ code: 'FORBIDDEN', message: 'Cannot upload to this artist' });
        }

        const result = await db.addPortfolio({
          artistId: input.artistId,
          imageUrl: input.imageUrl,
          imageKey: input.imageKey,
          title: input.title,
          description: input.description,
          styleId: input.styleId,
          displayOrder: input.displayOrder,
        });

        return result;
      }),
  }),

  /**
   * ============================================================
   * 申請相關路由
   * ============================================================
   */
  application: router({
    // 提交申請
    submit: protectedProcedure
      .input(z.object({
        shopName: z.string(),
        address: z.string(),
        phone: z.string(),
        email: z.string().email(),
        yearsOfExperience: z.number(),
        bio: z.string().optional(),
        region: z.string().optional(),
        website: z.string().optional(),
        socialMedia: z.record(z.string(), z.string()).optional(),
        styleIds: z.number().array(),
      }))
      .mutation(async ({ input, ctx }) => {
        const application = await db.createApplication({
          userId: ctx.user.id,
          shopName: input.shopName,
          address: input.address,
          phone: input.phone,
          email: input.email,
          yearsOfExperience: input.yearsOfExperience,
          bio: input.bio,
          region: input.region,
          website: input.website,
          socialMedia: input.socialMedia,
          status: 'pending',
        } as any);

        return application;
      }),

    // 獲取用戶的申請
    getMyApplications: protectedProcedure
      .query(async ({ ctx }) => {
        const applications = await db.getApplicationsByUserId(ctx.user.id);
        return applications;
      }),

    // 獲取待審核申請 (管理員)
    getPending: adminProcedure
      .input(z.object({
        limit: z.number().optional(),
        offset: z.number().optional(),
      }))
      .query(async ({ input }) => {
        const applications = await db.getPendingApplications(input.limit, input.offset);
        return applications;
      }),

    // 審核申請 (管理員)
    review: adminProcedure
      .input(z.object({
        applicationId: z.number(),
        status: z.enum(['approved', 'rejected']),
        rejectionReason: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const application = await db.getApplicationById(input.applicationId);
        if (!application) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Application not found' });
        }

        const result = await db.updateApplicationStatus(
          input.applicationId,
          input.status,
          input.rejectionReason,
          ctx.user.id
        );

        return result;
      }),
  }),

  /**
   * ============================================================
   * 紋身風格相關路由
   * ============================================================
   */
  tattooStyle: router({
    // 獲取所有紋身風格
    getAll: publicProcedure
      .query(async () => {
        const styles = await db.getAllTattooStyles();
        return styles;
      }),

    // 獲取單個紋身風格
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const style = await db.getTattooStyleById(input.id);
        if (!style) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Style not found' });
        }
        return style;
      }),
  }),

  /**
   * ============================================================
   * 未來擴展預留接口
   * ============================================================
   */

  /**
   * Web3D 線上紋身展
   * TODO: 實現以下功能
   * - 創建 3D 展覽
   * - 上傳 3D 模型
   * - 虛擬試紋功能
   * - 展覽排程與主題管理
   */
  // web3dExhibition: router({
  //   create: adminProcedure
  //     .input(z.object({
  //       title: z.string(),
  //       description: z.string().optional(),
  //       modelUrl: z.string().optional(),
  //       exhibitionDate: z.date().optional(),
  //     }))
  //     .mutation(async ({ input }) => {
  //       // TODO: 實現創建 3D 展覽邏輯
  //       return { success: true };
  //     }),
  //   list: publicProcedure.query(async () => {
  //     // TODO: 實現列表查詢邏輯
  //     return [];
  //   }),
  // }),

  /**
   * NFT 門票系統
   * TODO: 實現以下功能
   * - NFT 鑄造邏輯
   * - 智能合約集成
   * - 門票轉讓與驗證
   * - 區塊鏈網絡選擇 (Ethereum, Polygon, etc)
   */
  // nftTicket: router({
  //   mint: protectedProcedure
  //     .input(z.object({
  //       eventId: z.number(),
  //       quantity: z.number(),
  //     }))
  //     .mutation(async ({ input, ctx }) => {
  //       // TODO: 實現 NFT 鑄造邏輯
  //       return { success: true, tokenIds: [] };
  //     }),
  //   verify: publicProcedure
  //     .input(z.object({
  //       tokenId: z.string(),
  //     }))
  //     .query(async ({ input }) => {
  //       // TODO: 實現 NFT 驗證邏輯
  //       return { valid: true };
  //     }),
  // }),

  /**
   * 紋身比賽投票系統
   * TODO: 實現以下功能
   * - 比賽報名與參賽者管理
   * - 投票邏輯與防刷票機制
   * - 排行榜與獲獎管理
   * - 投票期限與計時
   */
  // tattooContest: router({
  //   create: adminProcedure
  //     .input(z.object({
  //       title: z.string(),
  //       description: z.string().optional(),
  //       startDate: z.date(),
  //       endDate: z.date(),
  //       maxParticipants: z.number().optional(),
  //     }))
  //     .mutation(async ({ input }) => {
  //       // TODO: 實現創建比賽邏輯
  //       return { success: true };
  //     }),
  //   list: publicProcedure.query(async () => {
  //     // TODO: 實現列表查詢邏輯
  //     return [];
  //   }),
  //   vote: protectedProcedure
  //     .input(z.object({
  //       contestId: z.number(),
  //       entryId: z.number(),
  //     }))
  //     .mutation(async ({ input, ctx }) => {
  //       // TODO: 實現投票邏輯與防刷票機制
  //       return { success: true };
  //     }),
  // }),
});

export type AppRouter = typeof appRouter;
