CREATE TABLE `application_portfolios` (
	`id` int AUTO_INCREMENT NOT NULL,
	`application_id` int NOT NULL,
	`image_url` text NOT NULL,
	`image_key` text NOT NULL,
	`title` varchar(255),
	`description` text,
	`display_order` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `application_portfolios_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `application_styles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`application_id` int NOT NULL,
	`style_id` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `application_styles_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `applications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`shop_name` varchar(255) NOT NULL,
	`address` text NOT NULL,
	`phone` varchar(20) NOT NULL,
	`email` varchar(320) NOT NULL,
	`years_of_experience` int NOT NULL,
	`bio` text,
	`region` varchar(100),
	`website` varchar(255),
	`social_media` json,
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`rejection_reason` text,
	`reviewed_at` timestamp,
	`reviewed_by` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `applications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `artist_styles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`artist_id` int NOT NULL,
	`style_id` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `artist_styles_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `artists` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`shop_name` varchar(255) NOT NULL,
	`address` text NOT NULL,
	`phone` varchar(20) NOT NULL,
	`email` varchar(320) NOT NULL,
	`years_of_experience` int NOT NULL,
	`bio` text,
	`profile_image_url` text,
	`status` enum('approved','pending','rejected') NOT NULL DEFAULT 'pending',
	`region` varchar(100),
	`website` varchar(255),
	`social_media` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `artists_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `portfolios` (
	`id` int AUTO_INCREMENT NOT NULL,
	`artist_id` int NOT NULL,
	`image_url` text NOT NULL,
	`image_key` text NOT NULL,
	`title` varchar(255),
	`description` text,
	`style_id` int,
	`display_order` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `portfolios_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tattoo_styles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(50) NOT NULL,
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `tattoo_styles_id` PRIMARY KEY(`id`),
	CONSTRAINT `tattoo_styles_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','admin','artist') NOT NULL DEFAULT 'user';