import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean, json } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "artist"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Tattoo Styles - 紋身風格列表
 * 預定義的紋身風格分類
 */
export const tattooStyles = mysqlTable("tattoo_styles", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 50 }).notNull().unique(), // 日式、美式傳統、寫實、幾何、水墨
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TattooStyle = typeof tattooStyles.$inferSelect;
export type InsertTattooStyle = typeof tattooStyles.$inferInsert;

/**
 * Artists - 紋身藝術家/店家資訊
 * 已審核通過的藝術家展示資料
 */
export const artists = mysqlTable("artists", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(), // 關聯到 users 表
  shopName: varchar("shop_name", { length: 255 }).notNull(),
  address: text("address").notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  yearsOfExperience: int("years_of_experience").notNull(), // 資歷年份
  bio: text("bio"), // 藝術家簡介
  profileImageUrl: text("profile_image_url"), // 頭像/店家照片
  status: mysqlEnum("status", ["approved", "pending", "rejected"]).default("pending").notNull(),
  region: varchar("region", { length: 100 }), // 地區
  website: varchar("website", { length: 255 }), // 官網連結
  socialMedia: json("social_media"), // JSON 格式存儲社群媒體連結 { instagram, facebook, etc }
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Artist = typeof artists.$inferSelect;
export type InsertArtist = typeof artists.$inferInsert;

/**
 * Artist Styles - 藝術家擅長的紋身風格 (多對多關係)
 */
export const artistStyles = mysqlTable("artist_styles", {
  id: int("id").autoincrement().primaryKey(),
  artistId: int("artist_id").notNull(),
  styleId: int("style_id").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ArtistStyle = typeof artistStyles.$inferSelect;
export type InsertArtistStyle = typeof artistStyles.$inferInsert;

/**
 * Portfolio - 作品集
 * 藝術家上傳的紋身作品照片
 */
export const portfolios = mysqlTable("portfolios", {
  id: int("id").autoincrement().primaryKey(),
  artistId: int("artist_id").notNull(),
  imageUrl: text("image_url").notNull(), // 儲存在雲端的圖片 URL
  imageKey: text("image_key").notNull(), // S3 儲存鍵
  title: varchar("title", { length: 255 }), // 作品標題
  description: text("description"), // 作品描述
  styleId: int("style_id"), // 該作品的紋身風格
  displayOrder: int("display_order").default(0), // 展示順序
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Portfolio = typeof portfolios.$inferSelect;
export type InsertPortfolio = typeof portfolios.$inferInsert;

/**
 * Applications - 店家申請記錄
 * 追蹤藝術家的申請歷史
 */
export const applications = mysqlTable("applications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  shopName: varchar("shop_name", { length: 255 }).notNull(),
  address: text("address").notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  yearsOfExperience: int("years_of_experience").notNull(),
  bio: text("bio"),
  region: varchar("region", { length: 100 }),
  website: varchar("website", { length: 255 }),
  socialMedia: json("social_media"),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  rejectionReason: text("rejection_reason"), // 拒絕原因
  reviewedAt: timestamp("reviewed_at"),
  reviewedBy: int("reviewed_by"), // 審核者 user_id
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Application = typeof applications.$inferSelect;
export type InsertApplication = typeof applications.$inferInsert;

/**
 * Application Styles - 申請表中選擇的紋身風格
 */
export const applicationStyles = mysqlTable("application_styles", {
  id: int("id").autoincrement().primaryKey(),
  applicationId: int("application_id").notNull(),
  styleId: int("style_id").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ApplicationStyle = typeof applicationStyles.$inferSelect;
export type InsertApplicationStyle = typeof applicationStyles.$inferInsert;

/**
 * Application Portfolio - 申請時上傳的作品照片
 */
export const applicationPortfolios = mysqlTable("application_portfolios", {
  id: int("id").autoincrement().primaryKey(),
  applicationId: int("application_id").notNull(),
  imageUrl: text("image_url").notNull(),
  imageKey: text("image_key").notNull(),
  title: varchar("title", { length: 255 }),
  description: text("description"),
  displayOrder: int("display_order").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ApplicationPortfolio = typeof applicationPortfolios.$inferSelect;
export type InsertApplicationPortfolio = typeof applicationPortfolios.$inferInsert;

/**
 * ============================================================
 * 未來擴展預留表結構
 * ============================================================
 */

/**
 * Web3D Exhibition - Web3D 線上紋身展
 * 預留介面：用於展示虛擬紋身、3D 模型、線上展覽
 * 
 * TODO: 實現時需考慮
 * - 3D 模型儲存與渲染
 * - 虛擬試紋功能
 * - 展覽排程與主題
 */
// export const web3dExhibitions = mysqlTable("web3d_exhibitions", {
//   id: int("id").autoincrement().primaryKey(),
//   title: varchar("title", { length: 255 }).notNull(),
//   description: text("description"),
//   modelUrl: text("model_url"), // 3D 模型 URL
//   exhibitionDate: timestamp("exhibition_date"),
//   createdAt: timestamp("createdAt").defaultNow().notNull(),
// });

/**
 * NFT Tickets - NFT 門票系統
 * 預留介面：限量 10,000 張 NFT 門票
 * 
 * TODO: 實現時需考慮
 * - NFT 鑄造邏輯
 * - 智能合約集成
 * - 門票轉讓與驗證
 * - 區塊鏈網絡選擇 (Ethereum, Polygon, etc)
 */
// export const nftTickets = mysqlTable("nft_tickets", {
//   id: int("id").autoincrement().primaryKey(),
//   tokenId: varchar("token_id", { length: 255 }).unique(),
//   ownerId: int("owner_id"),
//   eventId: int("event_id"),
//   contractAddress: varchar("contract_address", { length: 255 }),
//   mintedAt: timestamp("minted_at"),
//   createdAt: timestamp("createdAt").defaultNow().notNull(),
// });

/**
 * Tattoo Contest - 紋身比賽投票系統
 * 預留介面：用於舉辦紋身比賽與投票
 * 
 * TODO: 實現時需考慮
 * - 比賽報名與參賽者管理
 * - 投票邏輯與防刷票機制
 * - 排行榜與獲獎管理
 * - 投票期限與計時
 */
// export const tattooContests = mysqlTable("tattoo_contests", {
//   id: int("id").autoincrement().primaryKey(),
//   title: varchar("title", { length: 255 }).notNull(),
//   description: text("description"),
//   startDate: timestamp("start_date"),
//   endDate: timestamp("end_date"),
//   maxParticipants: int("max_participants"),
//   status: mysqlEnum("status", ["upcoming", "active", "closed", "finished"]),
//   createdAt: timestamp("createdAt").defaultNow().notNull(),
// });

// export const contestEntries = mysqlTable("contest_entries", {
//   id: int("id").autoincrement().primaryKey(),
//   contestId: int("contest_id").notNull(),
//   artistId: int("artist_id").notNull(),
//   portfolioId: int("portfolio_id"),
//   votes: int("votes").default(0),
//   createdAt: timestamp("createdAt").defaultNow().notNull(),
// });

// export const contestVotes = mysqlTable("contest_votes", {
//   id: int("id").autoincrement().primaryKey(),
//   contestId: int("contest_id").notNull(),
//   entryId: int("entry_id").notNull(),
//   voterId: int("voter_id"),
//   createdAt: timestamp("createdAt").defaultNow().notNull(),
// });
